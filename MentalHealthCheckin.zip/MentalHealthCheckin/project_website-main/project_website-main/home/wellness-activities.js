// Activity content and functionality
const activities = {
    meditation: {
        title: "Mindful Meditation",
        content: `
            <div class="activity-session">
                <div class="timer-container">
                    <div class="timer" id="meditationTimer">5:00</div>
                    <div class="timer-controls">
                        <button onclick="startTimer(300)" class="timer-button">Start</button>
                        <button onclick="pauseTimer()" class="timer-button">Pause</button>
                        <button onclick="resetTimer(300)" class="timer-button">Reset</button>
                    </div>
                </div>
                <div class="meditation-guide">
                    <h3>Guided Instructions:</h3>
                    <ol>
                        <li>Find a comfortable seated position</li>
                        <li>Close your eyes or maintain a soft gaze</li>
                        <li>Focus on your natural breath</li>
                        <li>When your mind wanders, gently return to your breath</li>
                        <li>Continue for the duration of the timer</li>
                    </ol>
                </div>
            </div>
        `
    },
    breathing: {
        title: "4-7-8 Breathing Exercise",
        content: `
            <div class="activity-session">
                <div class="breathing-container">
                    <div class="breathing-circle" id="breathingCircle"></div>
                    <div class="breathing-text" id="breathingText">Get Ready</div>
                    <button onclick="startBreathingExercise()" class="activity-button">Begin</button>
                </div>
                <div class="breathing-instructions">
                    <h3>4-7-8 Breathing Technique:</h3>
                    <ol>
                        <li>Inhale quietly through your nose for 4 seconds</li>
                        <li>Hold your breath for 7 seconds</li>
                        <li>Exhale completely through your mouth for 8 seconds</li>
                        <li>Repeat this cycle 4 times</li>
                    </ol>
                </div>
            </div>
        `
    },
    gratitude: {
        title: "Gratitude Journal",
        content: `
            <div class="activity-session">
                <div class="journal-container">
                    <div class="journal-prompts">
                        <h3>Today's Prompts:</h3>
                        <p>1. What made you smile today?</p>
                        <p>2. Name three things you're grateful for right now.</p>
                        <p>3. What's something good that happened recently?</p>
                    </div>
                    <textarea id="gratitudeEntry" placeholder="Start writing here..." rows="10"></textarea>
                    <div class="journal-actions">
                        <button onclick="saveGratitudeEntry()" class="journal-button">Save Entry</button>
                        <button onclick="viewPastEntries()" class="journal-button">View Past Entries</button>
                    </div>
                </div>
            </div>
        `
    },
    moodboard: {
        title: "Create Your Mood Board",
        content: `
            <div class="activity-session">
                <div class="moodboard-container">
                    <div class="moodboard-grid" id="moodboardGrid">
                        <!-- Mood board cells will be generated here -->
                    </div>
                    <div class="moodboard-controls">
                        <input type="color" id="colorPicker" value="#ffffff">
                        <button onclick="addMoodboardCell()" class="moodboard-button">Add Cell</button>
                        <button onclick="saveMoodboard()" class="moodboard-button">Save Board</button>
                    </div>
                </div>
            </div>
        `
    },
    affirmations: {
        title: "Daily Affirmations",
        content: `
            <div class="activity-session">
                <div class="affirmation-container">
                    <div class="affirmation-display" id="affirmationDisplay">
                        Click 'Next' to begin your affirmations
                    </div>
                    <div class="affirmation-controls">
                        <button onclick="previousAffirmation()" class="affirmation-button">Previous</button>
                        <button onclick="nextAffirmation()" class="affirmation-button">Next</button>
                    </div>
                    <div class="custom-affirmation">
                        <input type="text" id="customAffirmation" placeholder="Write your own affirmation">
                        <button onclick="addCustomAffirmation()" class="affirmation-button">Add</button>
                    </div>
                </div>
            </div>
        `
    },
    walking: {
        title: "Mindful Walking Guide",
        content: `
            <div class="activity-session">
                <div class="walking-guide">
                    <h3>Steps for Mindful Walking:</h3>
                    <ol>
                        <li>Find a quiet place to walk</li>
                        <li>Stand still and become aware of your body</li>
                        <li>Begin walking slowly and mindfully</li>
                        <li>Notice the sensation of each step</li>
                        <li>When your mind wanders, return focus to walking</li>
                    </ol>
                    <div class="walking-timer">
                        <div class="timer" id="walkingTimer">10:00</div>
                        <div class="timer-controls">
                            <button onclick="startWalkingTimer(600)" class="timer-button">Start</button>
                            <button onclick="pauseWalkingTimer()" class="timer-button">Pause</button>
                            <button onclick="resetWalkingTimer(600)" class="timer-button">Reset</button>
                        </div>
                    </div>
                </div>
            </div>
        `
    }
};

// Timer variables
let timerInterval;
let timeLeft;
let isPaused = false;
let breathingInterval;

// Initialize when the page loads
document.addEventListener('DOMContentLoaded', function() {
    // Initialize AOS
    AOS.init({
        duration: 800,
        easing: 'ease-in-out',
        once: true,
        mirror: false
    });

    // Add click handlers for activity buttons
    document.querySelectorAll('.activity-button').forEach(button => {
        button.addEventListener('click', function() {
            const activityType = this.getAttribute('data-activity');
            startActivity(activityType);
        });
    });

    // Add click handler for modal background
    document.getElementById('activityModal').addEventListener('click', function(event) {
        if (event.target === this) {
            closeModal();
        }
    });
});

// Activity functions
function startActivity(activityType) {
    const modal = document.getElementById('activityModal');
    const modalContent = document.getElementById('modalContent');
    const activity = activities[activityType];

    if (!activity) return;

    modalContent.innerHTML = `
        <h2>${activity.title}</h2>
        ${activity.content}
    `;
    modal.classList.add('show');
}

function closeModal() {
    const modal = document.getElementById('activityModal');
    modal.classList.remove('show');
    stopAllTimers();
}

// Timer functions
function startTimer(seconds) {
    if (isPaused) {
        isPaused = false;
    } else {
        timeLeft = seconds;
    }
    
    clearInterval(timerInterval);
    timerInterval = setInterval(() => {
        if (!isPaused) {
            timeLeft--;
            updateTimerDisplay();
            
            if (timeLeft <= 0) {
                clearInterval(timerInterval);
                alert('Timer completed!');
            }
        }
    }, 1000);
}

function pauseTimer() {
    isPaused = true;
}

function resetTimer(seconds) {
    clearInterval(timerInterval);
    timeLeft = seconds;
    isPaused = false;
    updateTimerDisplay();
}

function updateTimerDisplay() {
    const minutes = Math.floor(timeLeft / 60);
    const seconds = timeLeft % 60;
    const display = `${minutes}:${seconds.toString().padStart(2, '0')}`;
    document.getElementById('meditationTimer').textContent = display;
}

// Make functions globally available
window.startActivity = startActivity;
window.closeModal = closeModal;
window.startTimer = startTimer;
window.pauseTimer = pauseTimer;
window.resetTimer = resetTimer;

function stopAllTimers() {
    clearInterval(timerInterval);
    clearInterval(breathingInterval);
}

// Breathing exercise function
function startBreathingExercise() {
    const circle = document.getElementById('breathingCircle');
    const text = document.getElementById('breathingText');
    let phase = 'inhale';
    
    // Clear any existing interval
    if (breathingInterval) {
        clearInterval(breathingInterval);
    }

    // Initial state
    text.textContent = 'Inhale (4s)';
    circle.style.transform = 'scale(1)';

    function updateBreathing() {
        switch(phase) {
            case 'inhale':
                circle.style.transform = 'scale(1.5)';
                text.textContent = 'Inhale (4s)';
                setTimeout(() => {
                    if (phase === 'inhale') {
                        phase = 'hold';
                        text.textContent = 'Hold (7s)';
                    }
                }, 4000);
                break;
            case 'hold':
                setTimeout(() => {
                    if (phase === 'hold') {
                        phase = 'exhale';
                        circle.style.transform = 'scale(1)';
                        text.textContent = 'Exhale (8s)';
                    }
                }, 7000);
                break;
            case 'exhale':
                setTimeout(() => {
                    if (phase === 'exhale') {
                        phase = 'inhale';
                        text.textContent = 'Inhale (4s)';
                    }
                }, 8000);
                break;
        }
    }

    // Start the breathing cycle
    updateBreathing();
    breathingInterval = setInterval(updateBreathing, 19000); // Total cycle time
}

// Make sure the function is available globally
window.startBreathingExercise = startBreathingExercise;

// Gratitude journal functions
window.saveGratitudeEntry = function() {
    const entry = document.getElementById('gratitudeEntry').value;
    if (entry.trim() === '') return;

    const entries = JSON.parse(localStorage.getItem('gratitudeEntries') || '[]');
    entries.push({
        date: new Date().toISOString(),
        content: entry
    });
    localStorage.setItem('gratitudeEntries', JSON.stringify(entries));
    alert('Entry saved successfully!');
    document.getElementById('gratitudeEntry').value = '';
};

window.viewPastEntries = function() {
    const entries = JSON.parse(localStorage.getItem('gratitudeEntries') || '[]');
    if (entries.length === 0) {
        alert('No entries found');
        return;
    }

    const entriesHtml = entries.map(entry => `
        <div class="journal-entry">
            <div class="entry-date">${new Date(entry.date).toLocaleDateString()}</div>
            <div class="entry-content">${entry.content}</div>
        </div>
    `).join('');

    document.querySelector('.journal-container').innerHTML = `
        <div class="past-entries">
            <h3>Past Entries</h3>
            ${entriesHtml}
            <button onclick="startActivity('gratitude')" class="journal-button">Back to Journal</button>
        </div>
    `;
};

// Moodboard functions
window.addMoodboardCell = function() {
    const grid = document.getElementById('moodboardGrid');
    const color = document.getElementById('colorPicker').value;
    
    const cell = document.createElement('div');
    cell.className = 'moodboard-cell';
    cell.style.backgroundColor = color;
    cell.onclick = function() {
        this.style.backgroundColor = document.getElementById('colorPicker').value;
    };
    
    grid.appendChild(cell);
};

window.saveMoodboard = function() {
    const grid = document.getElementById('moodboardGrid');
    const colors = Array.from(grid.children).map(cell => cell.style.backgroundColor);
    
    const boards = JSON.parse(localStorage.getItem('moodboards') || '[]');
    boards.push({
        date: new Date().toISOString(),
        colors: colors
    });
    localStorage.setItem('moodboards', JSON.stringify(boards));
    alert('Mood board saved!');
};

// Affirmations functions
const defaultAffirmations = [
    "I am capable and strong",
    "I choose to be confident",
    "I am worthy of love and respect",
    "I trust in my abilities",
    "I am growing and learning every day"
];

let currentAffirmationIndex = -1;
let customAffirmations = JSON.parse(localStorage.getItem('customAffirmations') || '[]');

window.nextAffirmation = function() {
    const allAffirmations = [...defaultAffirmations, ...customAffirmations];
    currentAffirmationIndex = (currentAffirmationIndex + 1) % allAffirmations.length;
    document.getElementById('affirmationDisplay').textContent = allAffirmations[currentAffirmationIndex];
};

window.previousAffirmation = function() {
    const allAffirmations = [...defaultAffirmations, ...customAffirmations];
    currentAffirmationIndex = (currentAffirmationIndex - 1 + allAffirmations.length) % allAffirmations.length;
    document.getElementById('affirmationDisplay').textContent = allAffirmations[currentAffirmationIndex];
};

window.addCustomAffirmation = function() {
    const input = document.getElementById('customAffirmation');
    const affirmation = input.value.trim();
    
    if (affirmation) {
        customAffirmations.push(affirmation);
        localStorage.setItem('customAffirmations', JSON.stringify(customAffirmations));
        input.value = '';
        alert('Affirmation added!');
    }
};

// Export functions for module usage if needed
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        startActivity,
        closeModal,
        startTimer,
        pauseTimer,
        resetTimer
    };
}
