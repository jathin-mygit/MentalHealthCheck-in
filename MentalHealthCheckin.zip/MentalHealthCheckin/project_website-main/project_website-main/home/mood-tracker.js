document.addEventListener('DOMContentLoaded', function() {
    // Initialize AOS
    AOS.init({
        duration: 800,
        easing: 'ease-in-out',
        once: true,
        mirror: false
    });

    // Calendar functionality
    const calendarDays = document.getElementById('calendarDays');
    const currentMonthElement = document.getElementById('currentMonth');
    const prevMonthButton = document.getElementById('prevMonth');
    const nextMonthButton = document.getElementById('nextMonth');
    
    let currentDate = new Date();
    let selectedDate = new Date();

    // Mood tracking storage
    let moodData = JSON.parse(localStorage.getItem('moodData')) || {};

    function updateCalendar() {
        const year = currentDate.getFullYear();
        const month = currentDate.getMonth();
        
        // Update month display
        const monthNames = ['January', 'February', 'March', 'April', 'May', 'June',
                          'July', 'August', 'September', 'October', 'November', 'December'];
        currentMonthElement.textContent = `${monthNames[month]} ${year}`;
        
        // Clear previous calendar
        calendarDays.innerHTML = '';
        
        // Get first day of month and total days
        const firstDay = new Date(year, month, 1).getDay();
        const totalDays = new Date(year, month + 1, 0).getDate();
        
        // Add empty cells for days before first of month
        for (let i = 0; i < firstDay; i++) {
            const emptyDay = document.createElement('div');
            emptyDay.className = 'calendar-day empty';
            calendarDays.appendChild(emptyDay);
        }
        
        // Add days of month
        for (let day = 1; day <= totalDays; day++) {
            const dayElement = document.createElement('div');
            dayElement.className = 'calendar-day';
            
            const dateString = `${year}-${month + 1}-${day}`;
            if (moodData[dateString]) {
                dayElement.classList.add('has-mood');
                dayElement.innerHTML = `
                    ${day}
                    <span class="mood-emoji-small">${getMoodEmoji(moodData[dateString].mood)}</span>
                `;
            } else {
                dayElement.textContent = day;
            }
            
            // Highlight current day
            if (day === new Date().getDate() && 
                month === new Date().getMonth() && 
                year === new Date().getFullYear()) {
                dayElement.classList.add('current-day');
            }
            
            calendarDays.appendChild(dayElement);
        }
    }

    function getMoodEmoji(mood) {
        const moodEmojis = {
            'amazing': '😊',
            'good': '🙂',
            'okay': '😐',
            'down': '😔',
            'stressed': '😫'
        };
        return moodEmojis[mood] || '😐';
    }

    function updateStats() {
        const currentMonth = currentDate.getMonth();
        const currentYear = currentDate.getFullYear();
        
        // Filter moods for current month
        const monthMoods = Object.entries(moodData).filter(([date]) => {
            const moodDate = new Date(date);
            return moodDate.getMonth() === currentMonth && 
                   moodDate.getFullYear() === currentYear;
        });

        if (monthMoods.length > 0) {
            // Most common mood
            const moodCounts = monthMoods.reduce((acc, [_, data]) => {
                acc[data.mood] = (acc[data.mood] || 0) + 1;
                return acc;
            }, {});
            
            const commonMood = Object.entries(moodCounts)
                .sort((a, b) => b[1] - a[1])[0][0];
            document.getElementById('commonMood').textContent = 
                `${commonMood.charAt(0).toUpperCase() + commonMood.slice(1)} ${getMoodEmoji(commonMood)}`;

            // Mood trend
            const moodValues = {
                'amazing': 5,
                'good': 4,
                'okay': 3,
                'down': 2,
                'stressed': 1
            };

            const recentMoods = monthMoods.slice(-7);
            const trend = recentMoods.reduce((acc, [_, data], i) => {
                return acc + moodValues[data.mood] * (i + 1);
            }, 0) / recentMoods.length;

            document.getElementById('moodTrend').textContent = 
                trend > 3 ? 'Improving' : trend < 3 ? 'Needs Attention' : 'Stable';

            // Best day
            const bestDay = monthMoods.reduce((best, current) => {
                return moodValues[current[1].mood] > moodValues[best[1].mood] ? current : best;
            });
            
            const bestDate = new Date(bestDay[0]);
            document.getElementById('bestDay').textContent = 
                `${monthNames[bestDate.getMonth()]} ${bestDate.getDate()}`;
        }
    }

    // Event Listeners
    prevMonthButton.addEventListener('click', () => {
        currentDate.setMonth(currentDate.getMonth() - 1);
        updateCalendar();
        updateStats();
    });

    nextMonthButton.addEventListener('click', () => {
        currentDate.setMonth(currentDate.getMonth() + 1);
        updateCalendar();
        updateStats();
    });

    // Mood selection
    const moodButtons = document.querySelectorAll('.mood-button');
    let selectedMood = null;

    moodButtons.forEach(button => {
        button.addEventListener('click', () => {
            moodButtons.forEach(b => b.classList.remove('selected'));
            button.classList.add('selected');
            selectedMood = button.dataset.mood;
        });
    });

    // Save mood
    document.getElementById('saveMood').addEventListener('click', () => {
        if (!selectedMood) {
            alert('Please select a mood first!');
            return;
        }

        const today = new Date();
        const dateString = `${today.getFullYear()}-${today.getMonth() + 1}-${today.getDate()}`;
        
        moodData[dateString] = {
            mood: selectedMood,
            note: document.getElementById('moodNote').value
        };

        localStorage.setItem('moodData', JSON.stringify(moodData));
        
        updateCalendar();
        updateStats();
        
        // Reset selection
        moodButtons.forEach(b => b.classList.remove('selected'));
        document.getElementById('moodNote').value = '';
        selectedMood = null;

        // Show confirmation
        alert('Mood saved successfully!');
    });

    // Initial render
    updateCalendar();
    updateStats();
});
