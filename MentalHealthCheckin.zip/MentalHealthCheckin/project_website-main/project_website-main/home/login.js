document.getElementById('loginForm').addEventListener('submit', async function(e) {
    e.preventDefault();

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    try {
        const response = await fetch('/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                email,
                password: btoa(password) // Encode password to match registration
            })
        });

        const data = await response.json();

        if (response.ok) {
            alert('Login successful!');
            // Store user info in session storage
            sessionStorage.setItem('user', JSON.stringify(data.user));
            // Redirect to home page
            window.location.href = '/';
        } else {
            alert(data.error || 'Login failed. Please check your credentials.');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Login failed. Please try again.');
    }
});