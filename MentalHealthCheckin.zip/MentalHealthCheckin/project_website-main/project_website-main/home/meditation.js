document.addEventListener('DOMContentLoaded', function() {
    AOS.init({
        duration: 800,
        easing: 'ease-in-out',
        once: true,
        mirror: false
    });

    const minutesDisplay = document.getElementById('minutes');
    const secondsDisplay = document.getElementById('seconds');
    const startButton = document.getElementById('startButton');
    const decreaseButton = document.getElementById('decreaseTime');
    const increaseButton = document.getElementById('increaseTime');
    const breathingCircle = document.querySelector('.breathing-circle');
    const breathingText = document.querySelector('.breathing-text');
    
    let timeLeft = 600; // 10 minutes in seconds
    let isRunning = false;
    let timer = null;
    let breathingPhase = 'in';
    
    // Audio contexts and sounds
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
    const sounds = {
        rain: null,
        forest: null,
        waves: null
    };
    
    // Load audio files
    async function loadSound(name, url) {
        const response = await fetch(url);
        const arrayBuffer = await response.arrayBuffer();
        const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
        sounds[name] = audioBuffer;
    }
    
    // Initialize sound buttons
    document.querySelectorAll('.sound-button').forEach(button => {
        button.addEventListener('click', function() {
            const soundName = this.dataset.sound;
            playSound(soundName);
            
            // Toggle active state
            document.querySelectorAll('.sound-button').forEach(btn => {
                btn.classList.remove('active');
            });
            this.classList.add('active');
        });
    });
    
    function playSound(name) {
        if (sounds[name]) {
            const source = audioContext.createBufferSource();
            source.buffer = sounds[name];
            source.loop = true;
            source.connect(audioContext.destination);
            source.start();
        }
    }
    
    function updateDisplay() {
        const minutes = Math.floor(timeLeft / 60);
        const seconds = timeLeft % 60;
        minutesDisplay.textContent = minutes.toString().padStart(2, '0');
        secondsDisplay.textContent = seconds.toString().padStart(2, '0');
    }
    
    function startBreathing() {
        breathingCircle.style.animation = 'breathe 8s infinite';
        setInterval(() => {
            if (breathingPhase === 'in') {
                breathingText.textContent = 'Breathe out...';
                breathingPhase = 'out';
            } else {
                breathingText.textContent = 'Breathe in...';
                breathingPhase = 'in';
            }
        }, 4000);
    }
    
    function startTimer() {
        if (!isRunning) {
            isRunning = true;
            startButton.textContent = 'Pause';
            startBreathing();
            
            timer = setInterval(() => {
                timeLeft--;
                updateDisplay();
                
                if (timeLeft === 0) {
                    clearInterval(timer);
                    isRunning = false;
                    startButton.textContent = 'Start Meditation';
                    breathingCircle.style.animation = 'none';
                    alert('Meditation session completed!');
                }
            }, 1000);
        } else {
            clearInterval(timer);
            isRunning = false;
            startButton.textContent = 'Resume';
            breathingCircle.style.animationPlayState = 'paused';
        }
    }
    
    decreaseButton.addEventListener('click', () => {
        if (!isRunning && timeLeft > 300) { // Minimum 5 minutes
            timeLeft -= 300;
            updateDisplay();
        }
    });
    
    increaseButton.addEventListener('click', () => {
        if (!isRunning && timeLeft < 3600) { // Maximum 60 minutes
            timeLeft += 300;
            updateDisplay();
        }
    });
    
    startButton.addEventListener('click', startTimer);
    
    // Initial display update
    updateDisplay();
});
