document.addEventListener('DOMContentLoaded', function() {
    // Initialize AOS
    AOS.init({
        duration: 800,
        easing: 'ease-in-out',
        once: true,
        mirror: false
    });

    // Add click handlers for community buttons
    const communityButtons = document.querySelectorAll('.community-button');
    
    communityButtons.forEach(button => {
        button.addEventListener('click', function() {
            const action = this.textContent;
            
            // Handle different community actions
            switch(action) {
                case 'Join Group':
                    alert('Support group feature coming soon! Join our virtual support groups led by mental health professionals.');
                    break;
                case 'Enter Forum':
                    alert('Discussion forums coming soon! Connect with others in our moderated mental health community.');
                    break;
                case 'Get Help':
                    alert('24/7 Helpline: Please call 1-800-XXX-XXXX for immediate support.');
                    break;
                case 'Connect':
                    alert('Peer support matching system coming soon! Connect with trained volunteers.');
                    break;
                case 'Browse':
                    alert('Resource library coming soon! Access our curated collection of mental health materials.');
                    break;
                case 'Set Goals':
                    alert('Goal setting feature coming soon! Track your mental health journey with community support.');
                    break;
            }
        });
    });

    // FAQ Accordion functionality
    const faqItems = document.querySelectorAll('.faq-item');
    
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        
        question.addEventListener('click', () => {
            // Close all other FAQ items
            faqItems.forEach(otherItem => {
                if (otherItem !== item && otherItem.classList.contains('active')) {
                    otherItem.classList.remove('active');
                }
            });
            
            // Toggle current FAQ item
            item.classList.toggle('active');
        });
    });
});
