// Initialize AOS (Animate On Scroll)
document.addEventListener('DOMContentLoaded', function() {
    AOS.init({
        duration: 800,
        easing: 'ease-in-out',
        once: true,
        mirror: false
    });

    // Add click event listeners to buttons
    const buttons = document.querySelectorAll('.animated-button');
    buttons.forEach(button => {
        button.addEventListener('click', function(e) {
            // Create ripple effect
            const ripple = document.createElement('div');
            ripple.classList.add('ripple');
            
            const rect = button.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            ripple.style.left = x + 'px';
            ripple.style.top = y + 'px';
            
            button.appendChild(ripple);
            
            // Remove ripple after animation
            setTimeout(() => {
                ripple.remove();
            }, 1000);
            
            // Handle button clicks
            const buttonText = button.querySelector('.button-text').textContent;
            switch(buttonText) {
                case 'Community Support':
                    window.location.href = 'community-support.html';
                    break;
                case 'Quick Assessment':
                    window.location.href = 'quick-assessment.html';
                    break;
                case 'Stress Level Indicator':
                    window.location.href = 'stress-indicator.html';
                    break;
                case 'Mental Wellness Activities':
                    window.location.href = 'wellness-activities.html';
                    break;
                case 'Daily Mood Tracker':
                    window.location.href = 'mood-tracker.html';
                    break;
                case 'Analyse my mood':
                    window.location.href = 'analyse-mood.html';
                    break;
            }
        });
    });
});
