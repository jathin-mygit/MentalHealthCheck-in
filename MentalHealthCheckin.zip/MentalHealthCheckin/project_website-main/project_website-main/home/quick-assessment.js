document.addEventListener('DOMContentLoaded', function() {
    // Initialize AOS
    AOS.init({
        duration: 800,
        easing: 'ease-in-out',
        once: true,
        mirror: false
    });

    // Assessment questions
    const questions = [
        "How often do you feel overwhelmed by your emotions?",
        "How frequently do you experience difficulty concentrating?",
        "How often do you feel optimistic about the future?",
        "How frequently do you have trouble sleeping?",
        "How often do you feel supported by others?",
        "How frequently do you experience physical tension or stress?",
        "How often do you engage in activities you enjoy?",
        "How frequently do you feel anxious or worried?",
        "How often do you feel confident in handling challenges?",
        "How frequently do you experience mood swings?"
    ];

    let currentQuestion = 0;
    let answers = [];

    // DOM elements
    const introSection = document.getElementById('introSection');
    const questionSection = document.getElementById('questionSection');
    const resultsSection = document.getElementById('resultsSection');
    const questionText = document.getElementById('questionText');
    const progressBar = document.getElementById('progressBar');
    const startButton = document.getElementById('startAssessment');
    const optionButtons = document.querySelectorAll('.option-button');

    // Start assessment
    startButton.addEventListener('click', () => {
        introSection.style.display = 'none';
        questionSection.style.display = 'block';
        showQuestion();
    });

    // Handle option selection
    optionButtons.forEach(button => {
        button.addEventListener('click', () => {
            answers.push(parseInt(button.dataset.value));
            nextQuestion();
        });
    });

    function showQuestion() {
        questionText.textContent = questions[currentQuestion];
        progressBar.style.width = `${(currentQuestion / questions.length) * 100}%`;
    }

    function nextQuestion() {
        currentQuestion++;
        if (currentQuestion < questions.length) {
            showQuestion();
        } else {
            showResults();
        }
    }

    function calculateScores() {
        // Calculate category scores (example algorithm)
        const emotional = Math.round((answers[0] + answers[2] + answers[6]) / 12 * 10);
        const mental = Math.round((answers[1] + answers[3] + answers[7]) / 12 * 10);
        const coping = Math.round((answers[4] + answers[5] + answers[8]) / 12 * 10);
        
        return {
            emotional,
            mental,
            coping,
            overall: Math.round((emotional + mental + coping) / 3)
        };
    }

    function getRecommendations(scores) {
        const recommendations = [];
        
        if (scores.emotional < 7) {
            recommendations.push({
                icon: '🎨',
                text: 'Try art therapy or creative expression to process emotions'
            });
        }
        
        if (scores.mental < 7) {
            recommendations.push({
                icon: '🧘‍♂️',
                text: 'Practice daily meditation to improve mental clarity'
            });
        }
        
        if (scores.coping < 7) {
            recommendations.push({
                icon: '📝',
                text: 'Start a daily gratitude journal to build resilience'
            });
        }
        
        recommendations.push({
            icon: '🤝',
            text: 'Connect with our supportive community'
        });
        
        return recommendations;
    }

    function getFeedback(score) {
        if (score >= 8) return "Excellent! Keep maintaining these positive practices.";
        if (score >= 6) return "Good progress! There's room for some improvement.";
        if (score >= 4) return "You might benefit from additional support in this area.";
        return "This area needs attention. Consider seeking professional support.";
    }

    function showResults() {
        questionSection.style.display = 'none';
        resultsSection.style.display = 'block';

        const scores = calculateScores();

        // Animate score number
        const scoreNumber = document.getElementById('scoreNumber');
        let currentScore = 0;
        const targetScore = scores.overall;
        const scoreInterval = setInterval(() => {
            if (currentScore >= targetScore) {
                clearInterval(scoreInterval);
            } else {
                currentScore++;
                scoreNumber.textContent = currentScore;
            }
        }, 30);

        // Update category scores and feedback
        document.getElementById('emotionalScore').textContent = `${scores.emotional}/10`;
        document.getElementById('mentalScore').textContent = `${scores.mental}/10`;
        document.getElementById('copingScore').textContent = `${scores.coping}/10`;

        document.getElementById('emotionalFeedback').textContent = getFeedback(scores.emotional);
        document.getElementById('mentalFeedback').textContent = getFeedback(scores.mental);
        document.getElementById('copingFeedback').textContent = getFeedback(scores.coping);

        // Add recommendations
        const recommendationsList = document.getElementById('recommendationsList');
        const recommendations = getRecommendations(scores);
        
        recommendations.forEach(rec => {
            const recElement = document.createElement('div');
            recElement.className = 'recommendation-item';
            recElement.innerHTML = `
                <span class="recommendation-icon">${rec.icon}</span>
                <span class="recommendation-text">${rec.text}</span>
            `;
            recommendationsList.appendChild(recElement);
        });
    }
});
