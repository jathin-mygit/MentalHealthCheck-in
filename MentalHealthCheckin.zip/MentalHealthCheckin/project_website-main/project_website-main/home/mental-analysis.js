document.getElementById('analysisForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Collect form data
    const formData = new FormData(e.target);
    const data = {
        mood: parseInt(formData.get('mood')),
        sleep: formData.get('sleep'),
        stress: parseInt(formData.get('stress')),
        anxiety: formData.get('anxiety'),
        energy: parseInt(formData.get('energy'))
    };

    // Generate analysis
    const analysis = analyzeData(data);
    
    // Display report
    displayReport(analysis);
});

function analyzeData(data) {
    let analysis = {
        overallScore: 0,
        mentalState: '',
        details: [],
        recommendations: []
    };

    // Calculate overall score (0-100)
    const moodScore = data.mood * 20;
    const sleepScore = getSleepScore(data.sleep);
    const stressScore = (6 - data.stress) * 20; // Invert stress score
    const anxietyScore = getAnxietyScore(data.anxiety);
    const energyScore = data.energy * 20;

    analysis.overallScore = Math.round((moodScore + sleepScore + stressScore + anxietyScore + energyScore) / 5);

    // Determine mental state
    if (analysis.overallScore >= 80) {
        analysis.mentalState = 'Excellent';
    } else if (analysis.overallScore >= 60) {
        analysis.mentalState = 'Good';
    } else if (analysis.overallScore >= 40) {
        analysis.mentalState = 'Fair';
    } else {
        analysis.mentalState = 'Needs Attention';
    }

    // Generate detailed analysis
    analysis.details = [
        `Mood: ${getMoodAnalysis(data.mood)}`,
        `Sleep: ${getSleepAnalysis(data.sleep)}`,
        `Stress: ${getStressAnalysis(data.stress)}`,
        `Anxiety: ${getAnxietyAnalysis(data.anxiety)}`,
        `Energy: ${getEnergyAnalysis(data.energy)}`
    ];

    // Generate recommendations
    analysis.recommendations = generateRecommendations(data);

    return analysis;
}

function displayReport(analysis) {
    const reportContent = document.getElementById('reportContent');
    const recommendationsDiv = document.getElementById('recommendations');
    
    reportContent.innerHTML = `
        <div class="analysis-score">
            <h3>Overall Mental Wellness Score: ${analysis.overallScore}/100</h3>
            <h4>Current Mental State: ${analysis.mentalState}</h4>
        </div>
        <div class="analysis-details">
            <h3>Detailed Analysis:</h3>
            <ul>
                ${analysis.details.map(detail => `<li>${detail}</li>`).join('')}
            </ul>
        </div>
    `;

    recommendationsDiv.innerHTML = `
        <h3>Recommendations:</h3>
        <ul>
            ${analysis.recommendations.map(rec => `<li>${rec}</li>`).join('')}
        </ul>
    `;

    // Show report section and hide questionnaire
    document.getElementById('questionnaire').style.display = 'none';
    document.getElementById('report').style.display = 'block';
}

function startNewAnalysis() {
    document.getElementById('analysisForm').reset();
    document.getElementById('questionnaire').style.display = 'block';
    document.getElementById('report').style.display = 'none';
}

// Helper functions for scoring
function getSleepScore(sleep) {
    const scores = {
        'very-poor': 20,
        'poor': 40,
        'fair': 60,
        'good': 80,
        'very-good': 100
    };
    return scores[sleep];
}

function getAnxietyScore(anxiety) {
    const scores = {
        'none': 100,
        'mild': 75,
        'moderate': 50,
        'severe': 25
    };
    return scores[anxiety];
}

// Analysis helper functions
function getMoodAnalysis(score) {
    if (score >= 4) return "Your mood is very positive, which is excellent for mental health.";
    if (score >= 3) return "You have a moderately positive mood.";
    return "Your mood could use some improvement. Consider engaging in mood-lifting activities.";
}

function getSleepAnalysis(quality) {
    const analyses = {
        'very-good': "You're getting excellent sleep, which is crucial for mental health.",
        'good': "You're sleeping well, which helps maintain good mental health.",
        'fair': "Your sleep is adequate but could be improved.",
        'poor': "Poor sleep can affect mental health. Consider improving sleep habits.",
        'very-poor': "Your sleep needs immediate attention as it significantly impacts mental health."
    };
    return analyses[quality];
}

function getStressAnalysis(score) {
    if (score <= 2) return "You're managing stress well.";
    if (score <= 3) return "You're experiencing moderate stress levels.";
    return "Your stress levels are high. Consider stress management techniques.";
}

function getAnxietyAnalysis(level) {
    const analyses = {
        'none': "You're not experiencing anxiety, which is excellent.",
        'mild': "You're experiencing mild anxiety, which is manageable.",
        'moderate': "Your anxiety levels are moderate and might need attention.",
        'severe': "Your anxiety levels are high. Consider professional support."
    };
    return analyses[level];
}

function getEnergyAnalysis(score) {
    if (score >= 4) return "Your energy levels are excellent.";
    if (score >= 3) return "You have moderate energy levels.";
    return "Your energy levels could use improvement. Consider lifestyle changes.";
}

function generateRecommendations(data) {
    const recommendations = [];

    if (data.mood < 3) {
        recommendations.push("Try engaging in activities you enjoy");
        recommendations.push("Consider speaking with friends or family about your feelings");
    }

    if (data.sleep === 'poor' || data.sleep === 'very-poor') {
        recommendations.push("Establish a regular sleep schedule");
        recommendations.push("Create a relaxing bedtime routine");
    }

    if (data.stress > 3) {
        recommendations.push("Practice relaxation techniques like deep breathing or meditation");
        recommendations.push("Take regular breaks during the day");
    }

    if (data.anxiety === 'moderate' || data.anxiety === 'severe') {
        recommendations.push("Consider speaking with a mental health professional");
        recommendations.push("Try anxiety-reducing exercises");
    }

    if (data.energy < 3) {
        recommendations.push("Maintain a regular exercise routine");
        recommendations.push("Ensure you're eating a balanced diet");
    }

    if (recommendations.length === 0) {
        recommendations.push("Keep maintaining your current healthy habits");
        recommendations.push("Regular check-ins can help maintain good mental health");
    }

    return recommendations;
}