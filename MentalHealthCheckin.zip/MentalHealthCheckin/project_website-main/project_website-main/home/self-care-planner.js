// Store the plan data
let planData = {
    dailyActivities: [],
    weeklyGoals: [],
    reminders: []
};

// Add custom activity
function addCustomActivity(containerId) {
    const container = document.getElementById(containerId);
    const newActivity = document.createElement('div');
    newActivity.className = 'activity-item';
    newActivity.innerHTML = `
        <input type="checkbox">
        <input type="text" placeholder="Enter activity name" class="activity-input">
        <select class="time-select">
            <option value="5">5 min</option>
            <option value="10">10 min</option>
            <option value="15">15 min</option>
            <option value="20">20 min</option>
            <option value="30">30 min</option>
        </select>
        <button class="btn-remove" onclick="removeItem(this)">×</button>
    `;
    container.appendChild(newActivity);
}

// Add weekly goal
function addWeeklyGoal() {
    const container = document.getElementById('weeklyGoals');
    const newGoal = document.createElement('div');
    newGoal.className = 'goal-item';
    newGoal.innerHTML = `
        <input type="text" placeholder="Enter your weekly goal" class="goal-input">
        <select class="priority-select">
            <option value="low">Low Priority</option>
            <option value="medium">Medium Priority</option>
            <option value="high">High Priority</option>
        </select>
        <button class="btn-remove" onclick="removeItem(this)">×</button>
    `;
    container.appendChild(newGoal);
}

// Add reminder
function addReminder() {
    const container = document.getElementById('reminders');
    const newReminder = document.createElement('div');
    newReminder.className = 'reminder-item';
    newReminder.innerHTML = `
        <input type="text" placeholder="Enter reminder text" class="reminder-input">
        <input type="time" class="reminder-time">
        <select class="reminder-frequency">
            <option value="daily">Daily</option>
            <option value="weekdays">Weekdays</option>
            <option value="weekends">Weekends</option>
        </select>
        <button class="btn-remove" onclick="removeItem(this)">×</button>
    `;
    container.appendChild(newReminder);
}

// Remove item
function removeItem(button) {
    button.parentElement.remove();
}

// Save plan
function savePlan() {
    // Collect daily activities
    planData.dailyActivities = Array.from(document.querySelectorAll('.activity-item')).map(item => ({
        name: item.querySelector('label')?.textContent || item.querySelector('.activity-input')?.value,
        time: item.querySelector('.time-select').value,
        checked: item.querySelector('input[type="checkbox"]').checked
    }));

    // Collect weekly goals
    planData.weeklyGoals = Array.from(document.querySelectorAll('.goal-item')).map(item => ({
        goal: item.querySelector('.goal-input').value,
        priority: item.querySelector('.priority-select').value
    }));

    // Collect reminders
    planData.reminders = Array.from(document.querySelectorAll('.reminder-item')).map(item => ({
        text: item.querySelector('.reminder-input').value,
        time: item.querySelector('.reminder-time').value,
        frequency: item.querySelector('.reminder-frequency').value
    }));

    // Save to localStorage
    localStorage.setItem('selfCarePlan', JSON.stringify(planData));
    
    // Show saved plan
    displaySavedPlan();
}

// Display saved plan
function displaySavedPlan() {
    const savedPlan = document.getElementById('savedPlan');
    const planSummary = document.getElementById('planSummary');
    
    let summaryHTML = `
        <div class="plan-summary">
            <h3>Daily Activities</h3>
            <ul>
                ${planData.dailyActivities.map(activity => 
                    `<li>${activity.name} - ${activity.time} minutes</li>`
                ).join('')}
            </ul>

            <h3>Weekly Goals</h3>
            <ul>
                ${planData.weeklyGoals.map(goal => 
                    `<li>${goal.goal} (${goal.priority} priority)</li>`
                ).join('')}
            </ul>

            <h3>Reminders</h3>
            <ul>
                ${planData.reminders.map(reminder => 
                    `<li>${reminder.text} at ${reminder.time} (${reminder.frequency})</li>`
                ).join('')}
            </ul>
        </div>
    `;

    planSummary.innerHTML = summaryHTML;
    savedPlan.style.display = 'block';
}

// Export plan
function exportPlan() {
    const planText = `
Self-Care Plan

Daily Activities:
${planData.dailyActivities.map(activity => 
    `- ${activity.name} (${activity.time} minutes)`
).join('\n')}

Weekly Goals:
${planData.weeklyGoals.map(goal => 
    `- ${goal.goal} (${goal.priority} priority)`
).join('\n')}

Reminders:
${planData.reminders.map(reminder => 
    `- ${reminder.text} at ${reminder.time} (${reminder.frequency})`
).join('\n')}
    `;

    const blob = new Blob([planText], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'self-care-plan.txt';
    a.click();
    window.URL.revokeObjectURL(url);
}

// Load saved plan on page load
window.onload = function() {
    const savedPlan = localStorage.getItem('selfCarePlan');
    if (savedPlan) {
        planData = JSON.parse(savedPlan);
        displaySavedPlan();
    }
};